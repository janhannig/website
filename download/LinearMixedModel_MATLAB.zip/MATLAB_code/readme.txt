These MATLAB functions supplement the paper "Generalized Fiducial Inference for Normal Mixed Linear Models" By XXXX.

The two functions that the user will call are
1.  fid_nMLM.m - produces a generalized fiducial sample for the unknown parameters of a Normal Mixed Linear Model.
2.  fid_nMLM.m  - produces 100(1-alpha)% confidence intervals using the output of fid_nMLM.m

There are two helper functions for fid_nMLM.m:
1.  fid_sample.m
2.  fid_vertex.m

******* fid_nMLM.m********
[VERTEX,WEIGHT,ESS, p, r] = fid_nMLM(data,paramstruct)

1.  	SUMMARY OF FUNCTION - This function produces a fiducial sample for the unknown parameters of a normal mixed linear model.  An error effect is required, and will be added to all designs.  The current set-up does not allow for random-effects coefficients, but a more general function is currently under development.  The total number of random effects is r (including the error effect), and the total number of fixed effects is p.
 
2.  	DESCRIPTION OF INPUTS
	'data' are the nx2 data as intervals - if intervals are not defined, create artificial intervals.  See paper referenced above for more details.
		* The first column of Y should be the lower bound, the second column should be the upper bound.
 
	'paramstruct' - a Matlab structure of input parameters (see "help struct" and "help datatypes" for more information)
                    	* Create one, using commands of the form:
       				paramstruct = struct('field1',values1, 'field2',values2,'field3',values3) ;
		* The following are the optional parameters, mis-specified values revert to defaults
    			fields            	value
       			FE              	- n-by-p fixed effects design matrix 
                           				* default is n-by-1 vector of 1's
							* to exclude any fixed effects, set 'FE' = []
       			RE              	- n-by-(r-1) assignment of random effects (do NOT include a column for the error effect
                           				* Each column is a random effect with the values specifying the corresponding level for each data.
                           				* Do NOT include the error effect in RE; this will be added.
							* Levels should be positive integers starting with 1 for each column.
							* Cannot be used with fields 'V' or 'Levels'
			V               	- n-by-(total # of LEVELS of all random effects EXCEPT the error effect)
							* Each column specifies the coefficients for each level of each random effect
							* The current function only allows for V presented as an indicator for random effects 
							(i.e. only 1's and 0's allowed).  
							An updated general function allowing for coefficients for the random effects is currently under development.
							* Must specify 'Levels'
							* Effects must be in same order as listed in 'Levels'
			Levels          	- 1-by-(r-1) specifies number of levels for each effect.
							* Used in conjuction with V (required when V is used instead of 'RE')
       			N               	- desired number of particles to generate 
                           				* default is 1000
       			thresh          	- the threshold at which resampling occurs
                           				* default is 0.5N

	*** Currently it is not recommended to use a model design with more than 9 parameters.

3.  	DESCRIPTION OF OUTPUT
	'VERTEX' is a (p+r)-by-N matrix specifying the selected fiducial sample for each parameter.  Each row corresponds to an unknown parameter in the order
	of the input columns of FE followed by RE.  The last row of VERTEX is the sample for the error effect.
 
	'WEIGHT' is the weight associated with each particle of VERTEX matched by column.
 
	'ESS' is the effective sample size at each stage of the sampling.  Vector components are initially set to N and updated as particles are sampled.

******* fid_nMLM_ci.m********
[CI] = fid_nMLM_ci(VERTEX, WEIGHT, alpha, p, r)

1.	SUMMARY OF FUNCTION - This function produces 100 x (1 - alpha)% upper and lower confidence intervals, and 100 x (1 - 2 x alpha) two-sided confidence intervals using the fiducial sample of the unknown parameters of a normal mixed linear model from the function fid_nMLM.m.
 
	NOTE:  The intervals on the RE parameters are for sigma_i, i = 1,...,r where sigma_r is the error effect (i.e. the square-root of the variance component estimates.  
 
2.	DESCRIPTION OF INPUTS
	'VERTEX' is the (p+r)-by-N output matrix from fid_nMLM.m.  It contains the selected values of the sample.
 
	'WEIGHT' is the 1-by-N vector of weights associate with each column of VERTEX.
 
	'alpha' is selected to produce 100 x (1 - alpha)% one-sided confidence intervals, and 100 x (1 - 2 x alpha)% two-sided confidence intervals.
 
	'p' is the number of fixed effects and r is the number of random effects including the error component.
 
3.	DESCRIPTION OF OUTPUT
	The output matrix "CI" is an (fe+re)-by-2 matrix with the left column containing the lower bound to a 100x(1-alpha)% upper confidence interval, and the second column containing the upper bound to a 100x(1-alpha)% lower confidence interval.

	Combining the two columns produce a 100x(1-2xalpha)% two-sided confidence interval.


