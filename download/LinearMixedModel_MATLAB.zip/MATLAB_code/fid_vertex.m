function [VTtemp,CCtemp,vert] = fid_vertex(VT1,CC1,VTsum,U,L,m,dim,k,n)

%This function finds the updated vertices after each time step of the SMC
%algorithm of fid_nMLM.m, which produces a fiducial sample for the unknown parameters of
%a normal mixed linear model.

whichVT=zeros(m,2);
whichVT(:,1)=logical(VTsum>=L);
whichVT(:,2)=logical(VTsum<=U);
whichl=find(whichVT(:,1)==1); %vertices that satisfy lower constraint
whichu=find(whichVT(:,2)==1); %vertices that satisfy upper constraint
both=find(sum(whichVT,2)==2);

checkl=(1:m)';
checku=(1:m)';
checkl(whichl)=[];
checku(whichu)=[];
CCtemp=[];
VTtemp=[];
vert=0;
CA=CC1(:,checkl);
CB=CC1(:,whichl);

if isempty(checkl)==0 %i.e. they do not all satisfy the lower constraint
    INT = zeros(2*n,length(checkl));
    for ll=1:length(checkl) %check lower constraints first
        INT(CA(:,ll),ll)=1;
    end
    
    for ii=1:length(whichl)
        %use=[];
        INT2=INT(CB(:,ii),:);
        use=find(sum(INT2)==dim-1);
        
        for dd=1:length(use)
            inter=CB(INT2(:,use(dd))==1,ii); %this will be intersection
            vert=vert+1;
            CCtemp=[CCtemp,[inter;k+n]]; %need to add n indicating lower constraint
            lambda=(L-VTsum(whichl(ii)))/(VTsum(checkl(use(dd)))-VTsum(whichl(ii)));
            VTtemp=[VTtemp,lambda*VT1(:,checkl(use(dd)))+...
                (1-lambda)*VT1(:,whichl(ii))];
        end
    end
end
CA=CC1(:,checku);
CB=CC1(:,whichu);
if isempty(checku)==0 %i.e. they do not all satisfy the lower constraint
INT = zeros(2*n,length(checku));
    for ll=1:length(checku) %check lower constraints first
        INT(CA(:,ll),ll)=1;
    end
    
    for ii=1:length(whichu)
        %use=[];
        INT2=INT(CB(:,ii),:);
        use=find(sum(INT2)==dim-1);
        
        for dd=1:length(use)
            inter=CB(INT2(:,use(dd))==1,ii); %this will be intersection
            vert=vert+1;
            CCtemp=[CCtemp,[inter;k]]; %need to not to add n indicating upper constraint
            lambda=(U-VTsum(whichu(ii)))/(VTsum(checku(use(dd)))-VTsum(whichu(ii)));
            VTtemp=[VTtemp,lambda*VT1(:,checku(use(dd)))+...
                (1-lambda)*VT1(:,whichu(ii))];
        end
    end
end

if isempty(both)==0
    for ll=both'
        vert=vert+1;
        CCtemp=[CCtemp,CC1(:,ll)];
        VTtemp=[VTtemp,VT1(:,ll)];
    end
end 
CCtemp=sort(CCtemp,1);
[~,ICtemp,~]=unique(CCtemp','rows','stable');
CCtemp=CCtemp(:,ICtemp);
VTtemp=VTtemp(:,ICtemp);
vert=length(ICtemp);
end