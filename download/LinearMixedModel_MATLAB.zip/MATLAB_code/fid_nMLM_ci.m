function [CI] = fid_nMLM_ci(VERTEX, WEIGHT, alpha, p, r)

%%%%%%%%--------SUMMARY OF FUNCTION
%This function produces 100 x (1 - alpha)% upper and lower confidence
%intervals, and 100 x (1 - 2 x alpha) two-sided confidence intervals
%using the fiducial sample of the unknown parameters 
%of a normal mixed linear model from the function fid_nMLM.m.

%NOTE:  The intervals on the RE parameters are for sigma_i, i = 1,...,r
%where sigma_r is the error effect (i.e. the square-root of the variance
%component estimates.  

%%%%%%%%--------DESCRIPTION OF INPUTS
%   VERTEX is the (p+r)-by-N output matrix from fid_nMLM.m.  It contains
%   the selected values of the sample.

%   WEIGHT is the 1-by-N vector of weights associate with each column of
%   VERTEX.

%   alpha is selected to produce 100 x (1 - alpha)% one-sided confidence
%   intervals, and 100 x (1 - 2 x alpha)% two-sided confidence intervals.

%   p is the number of fixed effects and r is the number of random effects
%   including the error component.

%%%%%%%%--------DESCRIPTION OF OUTPUT
%The output matrix "CI" is an (fe+re)-by-2 matrix with the left column
%containing the lower bound to a 100x(1-alpha)% upper confidence interval, and the second
%column containing the upper bound to a 100x(1-alpha)% lower confidence interval.
%Combining the two columns produce a 100x(1-2xalpha)% two-sided confidence
%interval.

ci_ucb=zeros(p+r,1); %upper confidence bound (for lower confidence interval: (-inf, ci_ucb])
ci_lcb=zeros(p+r,1); %lower confidence bound (for upper confidence interval: [ci_lcb, inf))
N=length(VERTEX(1,:));
CI=zeros(p+r,2);
for est=1:p+r
    hat=zeros(2,N);
    hat(1,:)=VERTEX(est,:);
    hat(2,:)=WEIGHT;
    hatsort=sortrows(hat',1)';
    hatsum=cumsum(hatsort(2,:));
    ci_u=min(find(hatsum>=1-alpha)); %upper confidence bound
    ci_l=min(find(hatsum>=alpha));%lower confidence bound
    if isempty(ci_l)==0
        CI(est,1)=hatsort(1,ci_l); %lower bound
    end
    if isempty(ci_u)==0
        CI(est,2)=hatsort(1,ci_u); %upper bound
    end
end

