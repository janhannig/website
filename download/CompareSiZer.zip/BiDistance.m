function [distance]=BiDistance(A,B,ct,p,dis)
% inputs:
% A and B are binary images (0 and 1) of the same sizes
% ct = cutoff value, recommended value = 5
% p = pth order, recommended value = 2
% dis = 1 L1, 2 L2 distance

nh = size(A,1) ;
n = size (A,2) ;

A = A .* ones(nh,n) ;
a = repmat([1:nh]', n,1) ;
b = reshape(repmat([1:n], nh,1), nh*n,1) ;
c = [a b] ;
vA = reshape(A, nh*n,1) ;
c0 = c(vA == 0,:) ;
c1 = c(vA == 1,:) ;
if dis == 1 ;
    [idx,dist] = knnsearch(c1, c0, 'k', 1, 'Distance', 'Minkowski', 'P', 1) ; %L1 distance
elseif dis == 2 ;
    [idx,dist] = knnsearch(c1, c0, 'k', 1) ; %L2 distance
end ;
dA = zeros(nh*n,1) ;
dA(vA == 0) = dist ;
dA(dA > ct) = ct ;
dA = reshape(dA,nh,n) ;
clear c0 c1 idx dist ;

B = B .* ones(nh,n) ;
vB = reshape(B, nh*n,1) ;
c0 = c(vB == 0,:) ;
c1 = c(vB == 1,:) ;
if dis == 1 ;
    [idx,dist] = knnsearch(c1, c0, 'k', 1, 'Distance', 'Minkowski', 'P', 1) ; %L1 distance
elseif dis == 2 ;
    [idx,dist] = knnsearch(c1, c0, 'k', 1) ; %L2 distance
end ;
dB = zeros(nh*n,1) ;
dB(vB == 0) = dist ;
dB(dB > ct) = ct ;
dB = reshape(dB,nh,n) ;

distance = sqrt(sum(sum((dA-dB).^p))/(nh*n)) ;
