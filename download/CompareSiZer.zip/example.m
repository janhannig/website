clear ;
load szmapex ;
% Each SiZer map has the following four values: 1 - increasing, 2 - indecisive, 3 - insignificant, 4 - decreasing

sm_0(sm_0 == 2) = 3 ;  % indecisive -> insignificant
sm_2(sm_2 == 2) = 3 ;  % indecisive -> insignificant
nh = size(sm_0,1) ; % number of rows (bandwidths)
n = size(sm_0,2) ; % number of columns (grid)

% Binary distance
ct = 5 ; % threshold for distance
p = 2; % order
Ldist = 1 ; %L1 distance
vs = [1 4 3] ; % increasing, decreasing, insignificant

b_distan = [] ;

for j = 1:length(vs) ;
    
    flag = sm_0 == vs(j) ;
    A = flag .* ones(nh,n) ;
    
    flag = sm_2 == vs(j) ;
    B = flag .* ones(nh,n) ;
    dis = BiDistance(A,B,ct,p,Ldist) ;
    b_distan = [b_distan ; dis] ;
    
end ;

% binary distant
b_distan 

% Grayscale distance
sm_0(sm_0 == 3) = 0 ;  % insignificant
sm_0(sm_0 == 2) = 0 ;  % indecisive
sm_0(sm_0 == 4) = -1 ; % decreasing

sm_2(sm_2 == 3) = 0 ;  % insignificant
sm_2(sm_2 == 2) = 0 ;  % indecisive
sm_2(sm_2 == 4) = -1 ; % decreasing

ct = 5 ; % threshold for distance
p = 2 ; % order
vs = [1 -1 0] ; % red, blue, purple & gray

g_distan = GRAYDistance(sm_0,sm_2,ct,p) ;
g_distan
