function [distancerb,distancer,distanceb]=GRAYDistance(f,g,c,p)
% It is assumed that the sizer maps f,g are coded as follows:
%     -1 blue
%      0 purple & gray 
%      1 red


[n,m]=size(f);

[fbi,fbj]=ind2sub([n,m],find(f==-1));
[fpi,fpj]=ind2sub([n,m],find(f==0));
[fri,frj]=ind2sub([n,m],find(f==1));

[gbi,gbj]=ind2sub([n,m],find(g==-1));
[gpi,gpj]=ind2sub([n,m],find(g==0));
[gri,grj]=ind2sub([n,m],find(g==1));


distb=0;
distr=0;

distpb=0;
distpr=0;

for i=1:n
    for j=1:m
        minfp=min(abs(j-fpj)+abs(i-fpi));
        minfr=min(abs(j-frj)+abs(i-fri));
        minfb=min(abs(j-fbj)+abs(i-fbi));
        mingp=min(abs(j-gpj)+abs(i-gpi));
        mingr=min(abs(j-grj)+abs(i-gri));
        mingb=min(abs(j-gbj)+abs(i-gbi));
        
        distr=distr...
              +(min([2*c,max(c,minfp),minfr])-min([2*c,max(c,mingp),mingr]))^p;
          
        distpr=distpr...
              +(min([c,minfp,minfr])-min([c,mingp,mingr]))^p;    
          
        distb=distb...
              +(min([2*c,max(c,minfp),minfb])-min([2*c,max(c,mingp),mingb]))^p;
          
        distpb=distpb...
              +(min([c,minfp,minfb])-min([c,mingp,mingb]))^p;    
                   
    end
end

distancer=((distr+distpr)/(3*n*m))^(1/p);
distanceb=((distb+distpb)/(3*n*m))^(1/p);
distancerb=((distr+distb)/(2*n*m))^(1/p);


end

