example.m: example code to calculate binary and grayscale distances
szmapex.mat: two exemplary sizer maps
BiDistance.m: Matlab code for binary distance
GRAYDistance.m: Matlab code for GRAYDistance