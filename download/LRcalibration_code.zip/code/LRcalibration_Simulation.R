## Simulation Setting for calibration discrepancy
setwd("~/Dropbox/Documents/Research/NIST/LRmodel/code") #this needs to be updated to the appropriate directory
require(fitdistrplus)
source("FunctionDefNP.R")


##############################################################################
n=10000
set.seed(1)

y=rgamma(n,shape=10,scale=2) #thus was rgamma(n,shape=5,scale=2)
x=rgamma(n,shape=1,scale=2)

#exact LR
lrp = dgamma(y,shape=10,scale=2)/dgamma(y,shape=1,scale=2)
lrd = dgamma(x,shape=10,scale=2)/dgamma(x,shape=1,scale=2)

#simple diagnostics
c(mean(lrd),sd(lrd))
c(mean(1/lrp),sd(1/lrp))

brks2=seq(floor(min(log10(c(lrd,lrp)))),ceiling(log10(max(c(lrp,lrd)))),1)
hist(log10(lrp),freq=FALSE,xlim=range(brks2),
     col=rgb(0,0,1,0.2),breaks=brks2)
hist(log10(lrd),freq=FALSE,xlim=range(brks2),
     col=rgb(1,0,0,0.2),breaks=brks2,add=T)

calibration1=LRtestNP(rbind(data.frame(LLR=log10(lrp), H="P"),
                                 data.frame(LLR=log10(lrd), H="D")),
                           nfid=1000, AUC=TRUE)

calibrationPlot(calibration1$CI_NP,my_title ="True LR simulation",
                yaxis = c(-.5,.5))


#Approximate LR
ly=log10(y)
lx=log10(x)


outp=fitdist(ly,"norm",method="mle")
mup=outp$estimate[1]
sdp=outp$estimate[2]

outd=fitdist(lx,"norm",method="mle")
mud=outd$estimate[1]
sdd=outd$estimate[2]


LRp = dnorm(ly,mup,sdp)/dnorm(ly,mud,sdd)
LRd = dnorm(lx,mup,sdp)/dnorm(lx,mud,sdd)
c(mean(LRd),sd(LRd))
c(mean(1/LRp),sd(1/LRp))

brks4=seq(floor(min(log10(c(LRd[LRd>0],LRp)))),ceiling(log10(max(c(LRp,LRd)))),1)
hist(log10(LRp),freq=FALSE,xlim=range(brks4),
     col=rgb(0,0,1,0.2),breaks=brks4)
hist(log10(LRd),freq=FALSE,xlim=range(brks4),
     col=rgb(1,0,0,0.2),breaks=brks4,add=T)


calibration2=LRtestNP(rbind(data.frame(LLR=log10(LRp), H="P"),
                                 data.frame(LLR=log10(LRd), H="D")),
                           nfid=1000, AUC=TRUE)



calibrationPlot(calibration2$CI_NP,my_title = "Approximate LR Simulation",
                yaxis = c(-.1,.8))


##############################################################################

boxplot(data.frame(Exact=calibration1$AUC,Approximate=calibration2$AUC),
        main='AUC for simulated LRs',ylab='AUC')
