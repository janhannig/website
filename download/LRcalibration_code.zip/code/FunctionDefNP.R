library(foreach)
library(dplyr)
library(tidyr)

#Functions needed for non-parametric fiducial 
fiducial_sample<-function(lrt_data,nfid){
  ndata=length(lrt_data)
  return(list(data=sort(lrt_data),u=replicate(nfid,sort(runif(ndata),decreasing = TRUE)),n=ndata,nfid=nfid))
}

########################
particle_grid<-function(xgrid,lrt_fsample){
  ngrid=length(xgrid)
  grid=sort(xgrid)
  
  #pull out common information
  data=c(0,lrt_fsample$data,Inf)
  n=lrt_fsample$n #length(data)-2
  
  
  both_integrals=foreach(i = 1:lrt_fsample$nfid,
                         .combine=function(ls1,ls2){return(list(
                           cbind(ls1[[1]],ls2[[1]]),
                           cbind(ls1[[2]],ls2[[2]])))},
                         .init=list(numeric(),numeric()),
                         .final=function(ls1){return(list(
                           survival=ls1[[1]],bottom=ls1[[2]]
                         ))}) %do% {
                           #each fiducial sample processed separately
                           u=c(1,lrt_fsample$u[,i],0)
                           #compute integral at each data point
                           dataintegral=rev(cumsum(c(u[n+1]*(data[n+1]-data[n]+1/n),(data[(n+1):2]*u[n:1]-data[n:1]*u[(n+1):2])/2)))+
                             (data[n+1]*u[n+1]-data[1:(n+1)]*u[1:(n+1)])/2
                           
                           survival=rep(NA,ngrid)
                           integral=rep(NA,ngrid)
                           for(j in 1:ngrid){
                             #locate the grid point within data
                             index.ub=head(which(data>=grid[j]),n=1)
                             index.lb=tail(which(data<=grid[j]),n=1)
                             
                             if(index.ub<=index.lb){#if exactly hitting a grid point
                               survival[j]=u[index.lb]
                               integral[j]=dataintegral[index.lb]
                             }else if(index.ub==(n+2)){#beyond the range of data
                               gridoff=exp(-(grid[j]-data[n+1])/(data[n+1]-data[n]+1/n))
                               survival[j]=u[n+1]*gridoff
                               integral[j]=NaN #there is no reasonable way to estimate the integral plausible values [0,Inf]
                               #potential optin: dataintegral[n+1]*gridoff 
                             }else{#between data points
                               survival[j]=(u[index.ub]*(grid[j]-data[index.lb])+u[index.lb]*(data[index.ub]-grid[j]))/
                                 (data[index.ub]-data[index.lb])
                               integral[j]=dataintegral[index.ub]+(data[index.ub]-grid[j])*(survival[j]+u[index.ub])/2
                             }
                           }
                           list(survival,(grid*survival+integral))
                         }
  
  return(list(grid=grid, survival=both_integrals$survival, bottom= both_integrals$bottom, 
              nfid=lrt_fsample$nfid,n=lrt_fsample$n))
}

########################
fid_diff_log <- function(particle_top,particle_bottom,coarse_index=NA){
  grid=particle_top$grid
  if(sum(grid!=particle_bottom$grid)>0 || particle_bottom$nfid!=particle_top$nfid){
    warning('Mismatch of iputs')
    return(NA)}
  
  if(length(coarse_index)<=1){coarse_index=1:length(grid)}
  cindex=intersect(1:length(grid),coarse_index)
  if(length(cindex)<2){warning('Incompatible coarse_index')
    return(NA)}
  
  fidTop=particle_top$survival
  fidBottom=particle_bottom$bottom
  
  d_fid_Top=-diff(fidTop[cindex,])
  d_fid_Bottom=-diff(fidBottom[cindex,])
  
  fid_sample_slope_ratio=(log10((d_fid_Top))-log10((d_fid_Bottom)))
  
  coarsegrid=grid[cindex]
  
  return(list(fsample_top=fidTop, fsample_bottom=fidBottom, threshold_bottom=particle_bottom$threshold,
              n_top=particle_top$n,n_bottom=particle_bottom$n,nstan_bottom=particle_bottom$nstan,
              nfid=particle_top$nfid, fdiff_logratio=fid_sample_slope_ratio,
              grid=grid,dgrid=coarsegrid))
}

########################
fid_diff_CI<- function(fid_dif_sample,alpha=.05){
  fiducial_slope=fid_dif_sample$fdiff_logratio
  
  #uniform interval
  CI_center = apply(fiducial_slope,1,quantile,.5,na.rm=TRUE)#rowMeans(fiducial_slope)
  CI_scale  = rowMeans(abs(fiducial_slope-CI_center))
  fid_max=apply(abs((fiducial_slope-CI_center)/CI_scale),2,max,na.rm=TRUE)
  cut_off=quantile(fid_max,1-alpha,na.rm=TRUE)
  
  return(list(mean=CI_center, 
              uniform_lower=CI_center-cut_off*CI_scale,
              uniform_upper=CI_center+cut_off*CI_scale,
              median=CI_center,
              point_lower=apply(fiducial_slope,1,quantile,alpha/2,na.rm=TRUE),
              point_upper=apply(fiducial_slope,1,quantile,1-alpha/2,na.rm=TRUE),
              dgrid=fid_dif_sample$dgrid,
              threshold=fid_dif_sample$threshold))
}

########################
fid_diff_pval<- function(fid_dif_sample,shift=0){
  fiducial_slope=fid_dif_sample$fdiff_logratio
  
  #uniform interval
  CI_center = apply(fiducial_slope,1,quantile,.5,na.rm=TRUE)#rowMeans(fiducial_slope)
  pval  = rowMeans(fiducial_slope<=shift)
  
  return(list(median=CI_center,
              pval=pval,
              dgrid=fid_dif_sample$dgrid,
              threshold=fid_dif_sample$threshold))
}

########################
fid_diff_pval2x<- function(fid_dif_sample,shift=0,multiple=2){
  fiducial_slope=fid_dif_sample$fdiff_logratio
  
  #uniform interval
  CI_center = apply(fiducial_slope,1,quantile,.5,na.rm=TRUE)#rowMeans(fiducial_slope)
  pval  = rowMeans(fiducial_slope<=shift*(1-1/multiple)+CI_center/multiple)
  
  return(list(median=CI_center,
              pval=pval,
              dgrid=fid_dif_sample$dgrid,
              threshold=fid_dif_sample$threshold))
}



compare_CI<- function(compare_sample,alpha=.05){
  
  #uniform interval
  CI_center = apply(compare_sample,1,quantile,.5,na.rm=TRUE)
  CI_scale  = rowMeans(abs(compare_sample-CI_center))
  fid_max=apply(abs((compare_sample-CI_center)/CI_scale),2,max,na.rm=TRUE)
  cut_off=quantile(fid_max,1-alpha,na.rm=TRUE)
  
  return(list(mean=CI_center, 
              uniform_lower=CI_center-cut_off*CI_scale,
              uniform_upper=CI_center+cut_off*CI_scale,
              median=CI_center,
              point_lower=apply(compare_sample,1,quantile,alpha/2,na.rm=TRUE),
              point_upper=apply(compare_sample,1,quantile,1-alpha/2,na.rm=TRUE)))
}


fid_AUC<-function(fid_sample_top,fid_sample_bottom){#P(Top>Bottom)
  nfid=fid_sample_top$nfid
  fullgrid=sort(unique(c(fid_sample_top$data,fid_sample_bottom$data)))
  ngrid=length(fullgrid)
  top_surv=particle_grid(fullgrid,fid_sample_top)$survival
  bottom_surv=particle_grid(fullgrid,fid_sample_bottom)$survival
  
  auc=foreach(i=1:nfid,.combine=rbind)%do%{
    j=((i-1)%%fid_sample_bottom$nfid)+1
    c(1+sum(diff(c(1,top_surv[,i],0))*(c(1,bottom_surv[,j])+c(bottom_surv[,j],0))/2),
      -sum(diff(c(1,bottom_surv[,j],0))*(c(1,top_surv[,i])+c(top_surv[,i],0)))/2)
  }
  
  return(list(AUC=(auc[,1]+auc[,2])/2,nfid=nfid))
}

#######Main function 


LRtestNP <- function(data, hlable=c('P','D'), nfid=1000L, ncores=1L,GPDgrid=numeric(0),
                     display_plot=FALSE,yaxis=c(-3,3),AUC=TRUE){
  
  data=drop_na(data) #remove NA from LLR
  #unwrap data
  log_topdata = sort(data$LLR[data$H==hlable[1]])
  topdata=10^log_topdata
  log_bottomdata = sort(data$LLR[data$H==hlable[2]])
  bottomdata=10^log_bottomdata
  
  ##Default grid, GPD grid is on log10 scale
  if(length(GPDgrid)==0){
    pregrid=10^seq(from=floor(max(-2,min(log_topdata,na.rm=TRUE))),
                   to=ceiling(min(10,max(log_topdata,na.rm=TRUE))),by=1)
  }else{pregrid=10^GPDgrid}
  
  bottomdata=pmin(bottomdata,2*max(pregrid),na.rm = TRUE) 
  # Windorizing Hd true values well above the range of the grid. 
  # Will not  affect results while preventing overflow.
  
  
  
  grid=sort(union(pregrid,pregrid)) #threshold should be part of the gird
  idgrid=sapply(pregrid,function(x){which(x==grid)})
  
  ##plot the density
  if(display_plot){
    par(mfrow=c(2,2))
    
    dtop=density(log10(topdata))
    dbottom=density(log10(bottomdata))
    plot(range(dtop$x, dbottom$x), range(dtop$y, dbottom$y), type = "n", xlab = "log(LR)",
         ylab = "density", main="Density of log LR")
    lines(dtop, col = "red")
    lines(dbottom, col = "blue") 
    
    #plot cdf
    temp_range=range(c(log10(topdata),log10(bottomdata)))
    temp_range[1]=max(temp_range[1],-2.5)
    temp_range[2]=min(temp_range[2],10.5)
    plot(temp_range,c(0,1),type="n",
         xlab="log(reported LR)",
         ylab="probability",main="Survival function of log LR")
    lines(sort(log10(topdata)),1-(1:length(topdata))/length(topdata),col="red")
    lines(sort(log10(bottomdata)),1-(1:length(bottomdata))/length(bottomdata),col="blue")
  }
  #multi core support
  # if(ncores>1){
  #   my_cl <- makeCluster(ncores)
  #   registerDoParallel(my_cl)
  # }
  
  #run the non-parametric fiducial fit
  fid_sample_top=fiducial_sample(topdata,nfid) 
  fid_sample_bottom=fiducial_sample(bottomdata,nfid)
  
  fid_sample_top_grid=particle_grid(grid,fid_sample_top)
  fid_sample_bottom_grid=particle_grid(grid,fid_sample_bottom)
  
  if(AUC){
    fid_sample_auc=fid_AUC(fid_sample_top,fid_sample_bottom)
    if(display_plot){
      boxplot(fid_sample_auc$AUC,ylab = "AUC",main="Fiducial distribution of AUC")
    }
  }else{fid_sample_auc=data.frame(AUC=NA)}
  #multi core support
  # if(ncores>1){
  #   stopCluster(my_cl)
  # }
  # 
  
  
  #Non parametric comparison  
  fid_diff_NP = fid_diff_log(fid_sample_top_grid,fid_sample_bottom_grid,idgrid)
  fid_CI_NP=fid_diff_CI(fid_diff_NP)
  
  if(display_plot){
    dgrid=log10(fid_CI_NP$dgrid)
    plot(c(min(dgrid),max(dgrid)),yaxis,type="n",
         xlab="log10(reported LR)",
         ylab="interval-specific calibration discrepancy",
         main="Calibration Diagnostic Plot")
    xtick=dgrid
    
    lines(c(min(dgrid),max(dgrid)),c(0,0),col="red",lty=3)
    
    dgrid2=sort(c(dgrid[1:(length(dgrid)-1)],dgrid[2:length(dgrid)]))
    lines(dgrid2,kronecker(fid_CI_NP$median,c(1,1)),col="blue")
    lines(dgrid2,kronecker(fid_CI_NP$uniform_lower,c(1,1)),col="cyan",lty=2)
    lines(dgrid2,kronecker(fid_CI_NP$uniform_upper,c(1,1)), col="cyan",lty=2)
    lines(dgrid2,kronecker(fid_CI_NP$point_lower,c(1,1)),col="black")
    lines(dgrid2,kronecker(fid_CI_NP$point_upper,c(1,1)), col="black")
    
    par(mfrow=c(1,1))
  }
  #return results
  return(list(top=fid_sample_top_grid,bottom=fid_sample_bottom_grid,
              AUC=fid_sample_auc$AUC, CI_NP=fid_CI_NP))
}

calibrationPlot <- function(CI_NP, my_title="Calibration Diagnostic Plot",yaxis=numeric(0)){#should be converted to plot method 
  
  ishow=max(tail(which(!is.na(CI_NP$median)),n=1),tail(which(!is.na(CI_NP$median)),n=1))
  if(length(yaxis)==0){
    yaxis=c(floor(min(0,CI_NP$point_lower,na.rm = TRUE)),ceiling(max(0,CI_NP$point_upper,na.rm = TRUE)))
  }
  
  dgrid_const=log10(CI_NP$dgrid[1:(ishow+1)])
  plot(c(min(dgrid_const),max(dgrid_const)),yaxis,type="n",
       xlab="log10(reported LR)",
       ylab="interval-specific calibration discrepancy",
       main=my_title)
  xtick=dgrid_const
  
  lines(c(min(dgrid_const),max(dgrid_const)),c(0,0),col="red",lty=3)
  
  dgrid_const2=sort(c(dgrid_const[1:(length(dgrid_const)-1)],dgrid_const[2:length(dgrid_const)]))
  lines(dgrid_const2,kronecker(CI_NP$median[1:ishow],c(1,1)),col="blue")
  lines(dgrid_const2,kronecker(CI_NP$uniform_lower[1:ishow],c(1,1)),col="cyan",lty=2)
  lines(dgrid_const2,kronecker(CI_NP$uniform_upper[1:ishow],c(1,1)), col="cyan",lty=2)
  lines(dgrid_const2,kronecker(CI_NP$point_lower[1:ishow],c(1,1)),col="black")
  lines(dgrid_const2,kronecker(CI_NP$point_upper[1:ishow],c(1,1)), col="black")
}

