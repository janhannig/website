This zip file contains software for generating fiducial calibration plots. Files included are:

FunctionDefNP.R   containing internal function definitions
LRCalibration_Demo.R    showing examples of how to use the software on publicly available datasets
LRcalibration_Simulation.R    providing examples on how the method performs on simulated data with ground truth known

This software is still in developments and any suggestions for improvements are greatly appreciated.
