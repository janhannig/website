setwd('~/Dropbox/Documents/Research/NIST/LRmodel/code') #this needs to be updated to the appropriate directory
source("FunctionDefNP.R")

#paint - using defaults
load("ZadoraPaint_LRdata.RData")
paint.data=rbind(data.frame(LLR=log10(matedLR),labels="P"),data.frame(LLR=log10(nonmatedLR),labels="D"))

fiducialPaint=LRtestNP(data.frame(LLR=paint.data$LLR, H=paint.data$labels))

calibrationPlot(fiducialPaint$CI_NP)
boxplot(fiducialPaint$AUC,ylab = "AUC",main="Fiducial distribution of AUC")

#glass - not generating AUC (this speeds uo the code)
load("ZadoraGlass_LRdata.RData")

glass.data=rbind(data.frame(LLR=log10(matedLR),labels="P"),data.frame(LLR=log10(nonmatedLR),labels="D"))
fiducialGlass=LRtestNP(data.frame(LLR=glass.data$LLR, H=glass.data$labels),
                       AUC=FALSE)

calibrationPlot(fiducialGlass$CI_NP)

#ink - internal picture generation
load("LRink.RData") 
ink.data=rbind(data.frame(LLR=log10(dat$LR[dat$Label==1]),labels="P"),
               data.frame(LLR=log10(dat$LR[dat$Label==0]),labels="D"))

fiducialInk=LRtestNP(data.frame(LLR=ink.data$LLR, H=ink.data$labels),
                       display_plot = TRUE)
