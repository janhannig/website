function [VERTEX,WEIGHT,ESS, p, r] = fid_nMLM(data,paramstruct)

%%%%%%%%--------SUMMARY OF FUNCTION
% This function produces a fiducial sample for the unknown parameters of a
% normal mixed linear model.  The current set-up does not allow for
% random-effects coefficients, but a more general function is currently
% under development.
% An error effect is required, and will be added
% to all designs.

%%%%%%%%--------REQUIRED FUNCTIONS
% fid_sample.m, fid_vertex.m

%%%%%%%%--------DESCRIPTION OF INPUTS
% 'data' are the nx2 data as intervals - if intervals are not defined, create artificial intervals.  
%       * See paper referenced above for more details.
%       * The first column of Y should be the lower bound, the second column should be the upper bound.

% paramstruct - a Matlab structure of input parameters (see "help struct" and "help datatypes" for more information)
%       Use commands of the form:
%
%       paramstruct = struct('field1',values1,...
%                            'field2',values2,...
%                            'field3',values3) ;
%
%                          where any of the following can be used,
%                          these are optional, misspecified values
%                          revert to defaults
%       Example 1: paramstruct = struct('FE',FE,'RE',RE,'N',N,'thresh',thresh);
%       Example 2: paramstruct = struct('FE',FE,'V',V,'Levels',Levels,'N',N,'thresh',thresh);
%
%    fields            value
%       FE              - n-by-p fixed effects design matrix 
%                           * default is n-by-1 vector of 1's
%                           * to exclude any fixed effects, set 'FE' = []
%       RE              - n-by-(r-1) assignment of random effects (do NOT include a column for the error effect
%                           * Each column is a random effect with the values specifying the corresponding level for each data.
%                           * Do NOT include the error effect in RE; this will be added.
%                           * Levels should be positive integers starting
%                           with 1 for each column.
%                           * Cannot be used with fields 'V' or 'Levels'
%       V               - n-by-(total # of LEVELS of all random effects EXCEPT the error effect)
%                           * Each column specifies the coefficients for each level of each random effect
%                           * The current function only allows for V presented as an indicator for random effects 
%                           (i.e. only 1's and 0's allowed).  An updated general function allowing for coefficients for the
%                           random effects is currently under development.
%                           * Must specify 'Levels'
%                           * Effects must be in same order as listed in
%                           'Levels'
%       Levels          - 1-by-(r-1) specifies number of levels for each
%                           effect.
%                           * Used in conjuction with V (required when V is used instead of 'RE')
%       N               - desired number of particles to generate 
%                           * default is 1000
%       thresh          - the threshold at which resampling occurs
%                           * default is 0.5N
% *** Currently it is not recommended to use a model design with more than 9 parameters.

%%%%%%%%--------DESCRIPTION OF OUTPUT
%VERTEX is a (p+r)-by-N matrix specifying the selected fiducial sample for
%each parameter.  Each row corresponds to an unknown parameter in the order
%of the input columns of FE followed by RE.  The last row of VERTEX is the
%sample for the error effect.

%WEIGHT is the weight associated with each particle of VERTEX matched by
%column.

%ESS is the effective sample size at each stage of the sampling.  Vector
%components are initially set to N and updated as particles are sampled.

% % % %%%%%%%%--------SET UP ALGORITHM PARAMETERS
% Set all parameters to default
n=length(data(:,1));
FE = ones(n,1);
N=1000;
thresh=0.5*N;

%---------------------------------------------ALGORITHM
%  Now update parameters as specified,
%  by parameter structure (if it is used)
%
if nargin > 1 ;   %  then paramstruct has been added
    
    if isfield(paramstruct,'FE') ;    %  then change to input value
        FE = getfield(paramstruct,'FE') ;
    end ;
    
    if isfield(paramstruct,'RE') & isfield(paramstruct,'V');    %  'V' and 'RE' cannot both be used.
        error('ERROR:  Cannot specify both RE and V')
        
    elseif (isfield(paramstruct,'V')==1 & isfield(paramstruct,'Levels')==0)||... % 'Levels' and 'V' must be used together
            (isfield(paramstruct,'V')==0 & isfield(paramstruct,'Levels')==1)
        error('ERROR:  Both V and Levels must be specified.')
    end ;
     
    random_design=[];
    if isfield(paramstruct,'RE') ;    %  then change to input value
        RE = getfield(paramstruct,'RE') ;
        random_design = 1;
    end ;
    
    if isfield(paramstruct,'V') ;    %  then change to input value
        V = getfield(paramstruct,'V') ;
        if length(find(V>1))~=0
            error('ERROR:  Only 1s and 0s allowed in matrix V.  Updated general function is under development')
        end
        random_design = 2;
    end ;
    
    if isfield(paramstruct,'Levels') ;    %  then change to input value
        Levels = getfield(paramstruct,'Levels') ;
    end ;
    
    if isfield(paramstruct,'N') ;    %  then change to input value
        N = getfield(paramstruct,'N') ;
    end ;
    
    if isfield(paramstruct,'thresh') ;    %  then change to input value
        thresh = getfield(paramstruct,'thresh') ;
    end ;
    
end ;  %  of resetting of input parameters

Y = data;
if length(Y(1,:))==2
    L=Y(:,1);
    U=Y(:,2);
else
    error('ERROR:  Check the form of data:  should be n-by-2')
end

if sum(logical(U<L))>0
    error('ERROR:  Check the form of data:  data(i,1)<data(i,2), for i = 1:n')
end

break_point=10; % length of steps before recycling

if isempty(FE)==0
    fe=length(FE(1,:));
else
    fe=0; %only error component
end

%%%%%%%%--------SET-UP RANDOM EFFECTS
if random_design == 1       % RE is declared.
    re=length(RE(1,:))+1;
    E=zeros(1,re);
    E(1,re)=n;
    for i=1:re-1
        E(1,i)=length(unique(RE(:,i)));
    end
    ESUM=cumsum(E);
    assign = [RE,(1:n)'];  %Adds the error effect
    RE=[];
    for i=1:re %Builds an indicator matrix for the effects
        re_levels=unique(assign(:,i));
        for j=1:E(1,i)
            temp1=find(assign(:,i)==re_levels(j));
            temp2=zeros(n,1);
            temp2(temp1,1)=1;
            RE=[RE,temp2];
        end
    end
    
elseif random_design == 2       %V and Levels are declared
    RE=[V,eye(n)];
    E=[Levels,n];
    ESUM=cumsum(E);
    re=length(E);
    assign=zeros(n,re); % assigns the level per effect of each observation   
    for i=1:n
        for j=1:re
            temp=find(RE(i,sum(E(1,1:j))-E(1,j)+1:sum(E(1,1:j)))==1);
            if isempty(temp)==0
                assign(i,j)=temp;
            end
        end
    end
else
    RE=eye(n);
    assign=[1:n]';
    E=n;
    ESUM=n;
    re=1; 
end

dim=fe+re; %dimension of the space
rep=1;
%%%%%%%%--------SET-UP ALGORITHM OBJECTS

Z=cell(re,1);       %Particles
weight=cell(re,1);  %Weights
ESS=N*ones(n,1);    %Effective sample size
VC=zeros(1,N);      %Number of vertices
VT=cell(1,N);       %Verticies
CC=cell(1,N);       %Constraints

%%%%%%%%--------SAMPLE ALL Z's/SET-UP WEIGHTS

A=cell(N,1);
for i=1:re  %Sample all the Z's and set-up the weights
    Z{i,1}=randn(E(1,i),N);
    weight{i,1}=ones(E(1,i),N);
    for j=1:N
        A{j,1}=[A{j,1},RE(:,ESUM(1,i)-E(1,i)+1:ESUM(1,i))*Z{i,1}(:,j)];
    end
end

temp=[];
C=cell(1,N); %Initial constraints selected
for i=1;%:N
    AA=[[FE;-FE],[A{i,1};-A{i,1}]];
    AT=[];
    r=0;
    
    if rank(AA) ~= dim
        error('Design is not of full rank')
    else
        for k=1:n
            A_temp=[AT; AA(k,:)];
            r=rank(AT);
            if rank(A_temp)>r
                AT=A_temp;
                C{1,i}=[C{1,i};k];
            end
        end
    end
    K=[1:n];
    K_start=C{1,1};
    K(C{1,1})=[];
    Z{re,1}(K,:)=0; %remove error particles not selected in intitialization
    % K will be the values left to be sampled
end

%%%%%%%%--------FIND INITIAL VERTICES

USE=repmat(C{1,i}',2^dim,1); %all combinations of I
for j=1:dim
    if j==1
        USE(2^(dim-1)+1:2^(dim),1)=USE(1:2^(dim-1),1)+n;
    else
        temp=2^(j-2)+1;
        while temp<=2^(dim)
            for ii=1:2^(j-2)
                USE(temp,j)=USE(temp,j)+n;
                temp=temp+1;
            end
            temp=temp+2^(j-2);
        end
    end
end
for i=1:N
    V=zeros(dim,2^(dim));
    temp=0;
    for ii=1:2^dim %number of vertices
        II=USE(ii,:); %constraints to use are by row
        AA=[[FE;-FE],[A{i,1};-A{i,1}]];
        b=[U;-L];
        AA=AA(II,:);
        b=b(II);
        V(:,ii)=AA\b; 
    end
    VT{1,i}=V;
end
CC(1,1:N)={reshape(USE',dim,2^(dim))}; %constraints are the same for all N particles
VC=2^(dim)*ones(1,N);

%%%%%%%%--------MAIN ALGORITHM

K_n=ceil(length(K)/break_point);
K_temp=cell(1,K_n);
for i=1:K_n-1
    K_temp{1,i}=K((i-1)*break_point+1:i*break_point);
end
K_temp{1,K_n}=K((K_n-1)*break_point+1:end);

K1=[];
for k_n=1:K_n
    K1=[K1,K_temp{1,k_n}];
    for k=K_temp{1,k_n}
        effect=re; %only have the error term left
        level=k; %the level is the observation we are on
        if k_n>1
            for i=1:re
                Z{i,1}=[Z{i,1};randn(E(1,i)-length(Z{i,1}(:,1)),N)];
            end
        end
        for i=1:N
            m=VC(i);
            VT1=VT{1,i}; %vertex values
            VT2=VT1(fe+effect,:); %value to be resampled
            VT1(fe+effect,:)=[]; % remove value to be resampled
            if fe>0
                Z1=FE(k,:); %Assign fixed effect values
            else
                Z1=[];
            end
            for j=1:re
                if assign(k,j)==0
                    Z1=[Z1,0];
                else
                    Z1=[Z1,Z{j,1}(assign(k,j),i)];
                end
            end
            Z1(fe+effect)=[]; %remove column of effect to be sampled
            VTsum=(Z1*VT1)';
            [ZZ,wt]=fid_sample(VT2,VTsum,U(k),L(k));%%%Sample
            Z{effect,1}(k,i)=ZZ;
            weight{effect,1}(k,i)=wt;
            VTsum=VTsum+VT2'*Z{effect,1}(k,i);
            VT1=VT{1,i};
            CC1=CC{1,i};
            [VTtemp,CCtemp,vert] = fid_vertex(VT1,CC1,VTsum,U(k),L(k),m,dim,k,n);
            VC(1,i)=vert;
            CC{1,i}=CCtemp;
            VT{1,i}=VTtemp;
            if vert==0 %check
                weight{effect,1}(k,i)=0;
            end
        end
        WT=cumprod(weight{re,1}); %only last re is restricted
        WT=WT(end,:);
        if sum(WT(end,:))==0
            disp('!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!') ;
            disp('!!!   Error: possible underflow. !!!') ;
            disp('!!!   Potential resolutions:      !!!') ;
            disp('!!!   1.  Widen data intervals   !!!') ;
            disp('!!!   2.  Center data            !!!') ;
            disp('!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!') ;
            return ;
        end
        WT=WT/sum(WT);
        ESS(k,1)=1/(WT*WT');
        %---------------------------------------------------------------Resample
        if ESS(k,1)<thresh && k<K(end)
            u=zeros(1,N);
            N_sons=zeros(1,N);
            % generate the cumulative distribution
            dist=cumsum(WT/sum(WT));
            aux=rand(1);   % sample uniform rv in [0,1]
            u=aux:1:(N-1+aux);
            u=u./N;
            j=1;
            for i=1:N
                while (u(1,i)>dist(1,j))
                    j=j+1;
                end
                N_sons(1,j)=N_sons(1,j)+1;
            end
            KEEP(k,:)=N_sons;
            II=[1:n];
            II(unique([[1:k],C{1,1}']))=[]; %indicates which rows to remove from matrix
            JJ=[1:n];
            JJ(II)=[];
            ZZ=cell(re,1);
            VCVC=zeros(1,N);
            CCCC=cell(1,N);
            VTVT=cell(1,N);
            for i=1:N
                if N_sons(1,i)>0
                    VCtemp=VC(i)*ones(1,N_sons(1,i));
                    Ztemp=cell(re,1);
                    VTtemp=cell(1,N_sons(1,i));
                    copy=N_sons(1,i)-1; % # to be resampled
                    for ii=1:N_sons(1,i)
                        VTtemp{1,ii}=VT{1,i}; %copy original vertices
                    end
                    for ii=1:re
                        Ztemp{ii,1}=repmat(Z{ii,1}(:,i),1,N_sons(1,i)); %copy Z
                    end
                    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
                    if copy>0
                        for rr=1:rep
                            ord=sortrows([1:re;rand(1,re)]',2);
                            ord=ord(:,1)'; %Order to resample.  Each re will be resampled.
                            for kk=ord
                                for ii=1:copy
                                    CO=RE(JJ,:);
                                    XX=[];
                                    for jj=1:re
                                        XX=[XX,RE(:,ESUM(1,jj)-E(1,jj)+1:ESUM(1,jj))*Ztemp{jj,1}(:,ii)];
                                    end
                                    XX=XX(JJ,:);
                                    XX(:,kk)=[]; %remove column of effect to be resampled
                                    temp=find(assign(JJ,kk)~=0); %find which levels of kk have been sampled
                                    
                                    Z1=Ztemp{kk,1}(unique(assign(JJ(temp),kk)),ii); %Z being resampled
                                    CO2=RE(JJ,ESUM(1,kk)-E(:,kk)+1:ESUM(1,kk));
                                    level0=find(sum(abs(CO2))==0);%levels not sampled yet
                                    Z0=find(Z1==0); %Z's not sampled
                                    Z00=[1:length(Z1)];
                                    Z00(Z0)=[]; %These are the levels with Z for effect kk
                                    CO2(:,level0)=[];
                                    Z1(Z0)=[];
                                    if fe>0
                                        XX=[FE(JJ,:),XX];
                                    end
                                    MAT=[-XX,CO2];
                                    if rank(MAT)<length(MAT(1,:))
                                        NUL=null(MAT);
                                        n1=NUL(1:length(NUL(:,1))-length(CO2(1,:)),:);
                                        n2=NUL(length(NUL(:,1))-length(CO2(1,:))+1:end,:);
                                        O2=orth(n2);
                                        O1=XX\(CO2*O2);
                                        a=O2'*Z1;
                                        b=sqrt((Z1-O2*a)'*(Z1-O2*a));
                                        tau=(Z1-O2*a)/b;
                                        bb=sqrt(chi2rnd(length(Z1)-rank(O2),1,1));
                                        aa=randn(rank(O2),1);
                                        Ztemp{kk,1}(Z00,ii)=O2*aa+bb*tau;
                                        vert=[1:dim];
                                        vert(fe+kk)=[];
                                        for jj=1:VC(i)
                                            check1=XX*VTtemp{1,ii}(vert,jj)+VTtemp{1,ii}(fe+kk,jj)*CO2*Z1;
                                            VTtemp{1,ii}(vert,jj)=...
                                                VTtemp{1,ii}(vert,jj)-...%update this first
                                                VTtemp{1,ii}(fe+kk,jj)*O1*(b/bb*aa-a);
                                            VTtemp{1,ii}(fe+kk,jj)=...
                                                VTtemp{1,ii}(fe+kk,jj)*b/bb;
                                            check2=XX*VTtemp{1,ii}(vert,jj)+VTtemp{1,ii}(fe+kk,jj)*CO2*(O2*aa+bb*tau);
                                        end
                                    else
                                        b=sqrt((Z1)'*(Z1));
                                        tau=(Z1)/b;
                                        bb=sqrt(chi2rnd(length(Z1),1,1));
                                        Ztemp{kk,1}(Z00,ii)=bb*tau;
                                        vert=[1:dim];
                                        vert(fe+kk)=[];
                                        for jj=1:VC(i)
                                            VTtemp{1,ii}(fe+kk,jj)=...
                                                VTtemp{1,ii}(fe+kk,jj)*b/bb;
                                        end
                                        
                                    end
                                end
                            end
                        end
                    end
                    for ii=1:re
                        ZZ{ii,1}=[ZZ{ii,1},Ztemp{ii,1}];
                    end
                    [VTVT{1,sum(N_sons(1,1:i-1))+1:sum(N_sons(1,1:i))}]=deal(VTtemp{1,1:N_sons(1,i)});
                    VCVC(1,sum(N_sons(1,1:i-1))+1:sum(N_sons(1,1:i)))=VCtemp;
                    [CCCC{1,sum(N_sons(1,1:i-1))+1:sum(N_sons(1,1:i))}]=deal(CC{1,i});
                end
            end
            Z=ZZ;
            VT=VTVT;
            VC=VCVC;
            CC=CCCC;
            weight{re,1}=ones(E(1,re),N); %assign weights of error matrix to 1
        end
    end %ends reampling for k=K1
    
    %----------------------------------------------------determine signs
    sign=zeros(re,N);
    
    for i=1:N
        for j=1:re
            positive=logical(VT{1,i}(fe+j,:)>0);
            negative=logical(VT{1,i}(fe+j,:)<0);
            if sum(sum(abs(positive)))==VC(1,i) %i.e. all are positive
                sign(j,i)=1;
            elseif sum(sum(abs(negative)))==VC(1,i) %i.e. all are negative
                sign(j,i)=-1;
            end
        end
    end
    
 %----------------------------------------------------FINAL RESAMPLE
    ZZ=cell(re,1);
    for i=1:N
        Ztemp=cell(re,1);
        VTtemp=VT{1,i};
        n1=sort([K1';K_start]);
        nn=cell(re,1);
        
        for ii=1:re
            nn{ii,1}=unique(assign(n1,ii));
            Ztemp{ii,1}=Z{ii,1}(nn{ii,1},i); %copy Z
        end
        
        ord=sortrows([1:re;rand(1,re)]',2);
        ord=ord(:,1)'; %Order to resample.  Each re will be resampled.
        for kk=ord
            CO=RE;
            XX=[];
            eff=[1:re];
            eff(kk)=[];
            for jj=eff
                XX=[XX,RE(:,ESUM(1,jj)-E(1,jj)+1:ESUM(1,jj)-E(1,jj)+length(nn{jj,1}))*Ztemp{jj,1}];
            end
            temp=find(assign(:,kk)~=0); %find which levels of kk have been sampled
            
            Z1=Ztemp{kk,1}; %Z being resampled
            CO2=RE(:,ESUM(1,kk)-E(:,kk)+1:ESUM(1,kk)-E(1,kk)+length(nn{kk,1}));
            level0=find(sum(abs(CO2))==0);%levels not sampled yet
            Z0=find(Z1==0); %Z's not sampled
            Z00=[1:length(Z1)];
            Z00(Z0)=[]; %These are the levels with Z for effect kk
            CO2(:,level0)=[];
            Z1(Z0)=[];
            if fe>0
                XX=[FE,XX];
            end
            MAT=[-XX,CO2];
            if rank(MAT)<length(MAT(1,:))
                NUL=null(MAT);
                n1=NUL(1:length(NUL(:,1))-length(CO2(1,:)),:);
                n2=NUL(length(NUL(:,1))-length(CO2(1,:))+1:end,:);
                O2=orth(n2);
                O1=XX\(CO2*O2);
                a=O2'*Z1;
                b=sqrt((Z1-O2*a)'*(Z1-O2*a));
                tau=(Z1-O2*a)/b;
                bb=sqrt(chi2rnd(length(Z1)-rank(O2),1,1));
                aa=randn(rank(O2),1);
                Ztemp{kk,1}(Z00,1)=O2*aa+bb*tau;
                vert=[1:dim];
                vert(fe+kk)=[];
                for jj=1:VC(i)
                    VTtemp(vert,jj)=...
                        VTtemp(vert,jj)-...%update this first
                        VTtemp(fe+kk,jj)*O1*(b/bb*aa-a);
                    VTtemp(fe+kk,jj)=...
                        VTtemp(fe+kk,jj)*b/bb;
                end
            else
                b=sqrt((Z1)'*(Z1));
                tau=(Z1)/b;
                bb=sqrt(chi2rnd(length(Z1),1,1));
                Ztemp{kk,1}(Z00,1)=bb*tau;
                vert=[1:dim];
                vert(fe+kk)=[];
                for jj=1:VC(i)
                    VTtemp(fe+kk,jj)=...
                        VTtemp(fe+kk,jj)*b/bb;
                end
                
            end
        end
        
        for ii=1:re
            ZZ{ii,1}=[ZZ{ii,1},Ztemp{ii,1}];
        end
        [VTVT{1,i}]=VTtemp;
    end
    Z=ZZ;
    VT=VTVT;
    
    %----------------------------------------------------flip negatives
    for i=1:N
        for j=1:re %only look at random effects
            if sign(j,i)==-1
                VT{1,i}(fe+j,:)=-VT{1,i}(fe+j,:); %only need to flip the negatives
                Z{j,1}(:,i)=-Z{j,1}(:,i);
                
            end
        end
    end
    
    %pick the coordinates
    VT_end=zeros(fe+re,N);
    for i=1:N
        for j=1:re+fe
            if rand(1)<=0.5
                if j<=fe
                    VT_end(j,i)=min(VT{1,i}(j,:));
                else
                    VT_end(j,i)=max(min(VT{1,i}(j,:)),0);
                end
            else
                if j<=fe
                    VT_end(j,i)=max(VT{1,i}(j,:));
                else
                    VT_end(j,i)=max(max(VT{1,i}(j,:)),0);
                end
            end
        end
    end
    
    if k_n == K_n %if finished pick coordinates
        %pick the coordinates
        VT_end=zeros(fe+re,N);
        for i=1:N
            for j=1:re+fe
                if rand(1)<=0.5
                    if j<=fe
                        VT_end(j,i)=min(VT{1,i}(j,:));
                    else
                        VT_end(j,i)=max(min(VT{1,i}(j,:)),0);
                    end
                else
                    if j<=fe
                        VT_end(j,i)=max(VT{1,i}(j,:));
                    else
                        VT_end(j,i)=max(max(VT{1,i}(j,:)),0);
                    end
                end
            end
        end
        
        VERTEX=VT_end;
        WEIGHT=WT;
        p=fe;
        r=re;
    end
end















