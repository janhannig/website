%*********************TWO-FOLD NESTED MODEL EXAMPLE
%%%%%%%%-------REQUIRED FUNCTIONS  
% fid_nMLM.m, fid_nMLM_ci.m,  fid_sample.m, fid_vertex.m

%Here is the data generated from a two-fold nested model (1 fixed effect
%and 3 random effects) with the fixed effect = 0, and the random effects
%sig1=2, sig2=1 and sige=1.  The recorded observation falls between the
%Lower and Upper bounds, and the level of the first and second random
%effect associated with that data value is listed below.  Note that each
%data interval has its own error effect level, which is not listed below.

% Lower     Upper       Level r.e. 1    Level of r.e. 2
% 1.624     1.625       1               1
% 2.209     2.210       1               1
% 2.097     2.098       1               1
% 0.558     0.559       1               1
% -0.335    -0.334      1               2
% -0.971    -0.970      1               2
% -1.650    -1.649      1               2
% -2.338    -2.337      1               2
% -3.290    -3.289      2               3
% -4.291    -4.290      2               3
% 2.862     2.863       3               4
% 2.023     2.024       3               4
% -2.336    -2.335      4               5
% -0.613    -0.612      4               5
% -0.907    -0.906      5               6
% 0.354     0.355       5               6

%Generated data:  
data= [1.624,1.625;2.209,2.210;2.097,2.098;0.558,0.559;...
    -0.335,-0.334;-0.971,-0.970;-1.650,-1.649;...
    -2.338,-2.337;-3.290,-3.289;-4.291,-4.290;2.862,2.863;...
    2.023,2.024;-2.336,-2.335;-0.613,-0.612;-0.907,-0.906;...
    0.354,0.355;];
%Random effects design
RE=[1,1;1,1;1,1;1,1;1,2;1,2;1,2;1,2;2,3;2,3;3,4;3,4;4,5;4,5;5,6;5,6;];
%Fixed effects design
FE = ones(length(data(:,1)),1);
paramstruct = struct('FE',FE,'RE',RE,'N',1000);
[VERTEX,WEIGHT,ESS,p,r] = fid_nMLM(data,paramstruct);
alpha=0.05;
CI=fid_nMLM_ci(VERTEX, WEIGHT, alpha, p, r) %Confidence intervals to be displayed