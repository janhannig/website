Some highlights of the package

FMSInterLab.m: Main function 
FMSInterLabtest.m: test script
FMSInterLabPaperDemo.m: script for generating data examples in the paper 
 
