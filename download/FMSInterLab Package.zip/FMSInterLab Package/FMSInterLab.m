function outstruct = FMSInterLab(datastruct)
% Main function to find a robust consensus of several independently derived 
% collection of con?dence distributions based on a Generalized Fiducial 
% Inference inspired model selection method 
% A popular application is the inter-laboratory trials, where different 
% national laboratories all measure same unknown true value of a quantity 
% and report their con?dence distributions

% Inputs:
%   Input: 
%   datastruct      - a Matlab structure of input parameters
%                     Use: "help struct" and "help datatypes" to
%                         learn about these.
%                     Create one, using commands of the form:
%
%                   datastruct = struct('field1',values1,...
%                                       'field2',values2,...
%                                       'field3',values3) ;
%
%                          where any of the following can be used,
%                          these are optional, misspecified values
%                          revert to defaults
%
%                    Version for easy copying and modification:
%                    datastruct = struct('',, ...
%                                        '',, ...
%                                        '',) ;
%
%    fields            values
%    vxbar             - a vector of reported measurement of each lab
%    vse               - a vector of combined standard error provided by each lab
%    vdna              - a vector of type A degrees of freedom of each lab
%                        required input with no default value provided.
%                        vdna = number of samples - 1
%    vdnt              - a vector of total degrees of freedom of each lab
%                        default value is vdna i.e. assume no type B
%                        error; total d.f. is equal to type A d.f.

%    nfiducial         - number of the fiducial sample to generate for each group
%                        default is 10000
%    preferredlab      - a vector of lab indices that must be included in the model.
%                        default is [] i.e. all 2^k-1 models are considered                   
%                        if preferredlab set to [1, ..., k], no model
%                        selection just fiducial combination 
%    iCI               - a number to indicate whether to output confidence
%                        interval of obtained fiducial samples, e.g. iCI =
%                        95 gives 95% confidence interval of obtained
%                        samples; default is 0 i.e. no CI provided.
%    iplot             - indicator for generating kernel density estimates
%                        plots / confidence curves of obtained fiducial samples; default = [0
%                        0] i.e no plot
%                     
%   Output: MATLAB struct with fields
%   musample: fiducial samples obtained for each lab (a vector: 1 X
%   (k*nfiducial))
%   muweight: corresponding weights (a vector: 1 X
%   (k*nfiducial))
%   CI(optional): confidence interval of obtained fiducial samples

% Assumes path can find personal functions:
%    KeyLikelihoodE2.m
%    logtpdf.m
%    FMSInterLabkde.m
%    FMSInterLabcc.m

%    Copyright (c)  Jan Hannig, Hari Iyer & Qing Feng 2016



% check input 
if isfield(datastruct,'vxbar') ;
    vxbar = getfield(datastruct,'vxbar') ;
else
    disp('Error: terminated due to missing input of vxbar!') ;
    return;
end;

if isfield(datastruct,'vse') ;
    vse = getfield(datastruct,'vse') ;  % standard error
else
    disp('Error: terminated due to missing input of vse!') ;
    return;
end;

if isfield(datastruct,'vdna') ;
    vdna  = getfield(datastruct,'vdna') ;  % total degree of freedom
else
    disp('Error: terminated due to missing input of vdna!') ;
    return;
end;

k = length(vxbar); % number of labs
laboneind = ones(k,1); % indicator of lab inclusion 

if length(vse)~= k || length(vdna)~= k;
    disp('Error: terminated due to unmatched number of labs!') ;
    return;
end

% initial default values
preferredlab = []; % no exclusion of any lab
nfiducial  = 10000; % # of fiducial samples
vdnt = vdna;
iCI = 0; 
iplot = [0 0];

if isfield(datastruct,'preferredlab') ;
    preferredlab = getfield(datastruct, 'preferredlab') ;
end;

if isfield(datastruct,'nfiducial') ;
    nfiducial = getfield(datastruct, 'nfiducial') ;
end;

if isfield(datastruct,'vdnt') ;
    vdnt = getfield(datastruct, 'vdnt') ;
end;

if isfield(datastruct,'iCI') ;
    iCI = getfield(datastruct, 'iCI') ;
end;

if isfield(datastruct,'iplot') ;
    iplot = getfield(datastruct, 'iplot') ;
end;

if length(preferredlab) == k;
    disp('Note: no model selection !');
    disp('Potentially unreliable results due to underflow !');
end;
laboneind(preferredlab) = 0;
ipenalty=-log(mean(sqrt(vdna./vdnt).*(vdna+1).*(vse.^2)))+log(sum(vse.^(-2)))/2+log(sum(vdna+1))/2;

%sample of the mu's
matmu=ones(nfiducial,1)*vxbar'-trnd(ones(nfiducial,1)*vdnt')*diag(vse);
matweight =zeros(nfiducial,k);

for i=1:k
   prelweighti=-Inf*ones(nfiducial,k);
   for j=1:k
       if i~=j
          prelweighti(:,j)=KeyLikelihoodE2(matmu(:,i),vdnt(j),vdna(j),vxbar(j),vse(j));
       end
   end
   matweight(:,i)=prod(ones(nfiducial,1)*laboneind'+exp(ipenalty+prelweighti),2);
end

musample = matmu(1:k*nfiducial);
muweight = matweight(1:k*nfiducial);
outstruct.musample = musample;
outstruct.muweight = muweight;

if iCI > 0;
    lq = (1-iCI/100)/2;
    sweight = sum(muweight);
    ess = (sweight^2./sum(muweight.^2));
    [musamplesorted,index] = sort(musample);
    cummuweightsorted = cumsum(muweight(index)/sweight);
    CI = musamplesorted([find(cummuweightsorted <= lq, 1, 'last'), ...
                         find(cummuweightsorted >= (1-lq), 1, 'first')]);
    outstruct.CI = CI;
end

if iplot(1) == 1;
    FMSInterLabkde(musample, muweight, k);
end

if iplot(2) == 1;
    FMSInterLabcc(musample, muweight, k);
end;
