function logplike = KeyLikelihoodE2(vmu,dnt,dna,xbar,se)
% function to compute fiducial profile likelihood
% 
% Inputs:
% vmu   - a vector of values at which we are evaluating the likelihood
% dnt   - the total degrees of freedom (for this lab)
% dna   - the type A degrees of freedom (for this lab)
% xbar  - observed mean (for this lab)
% se    - observed standard deviation (for this lab)

% Output
% logplike: fiducial profile likelihood 

% Assumes path can find personal functions:
%    logtpdf.m

%    Copyright (c)  Jan Hannig, Hari Iyer & Qing Feng 2016

nmu = length(vmu);
logc = -(log(se)+.5*log(dna+1))*ones(nmu,1);
tempZ = (vmu-xbar)/se;
logT = logtpdf(tempZ,dnt);
logJp = .5*log(1+tempZ.^2/sqrt(dna*dnt));

logplike = logc + logT + logJp; 

end
    
