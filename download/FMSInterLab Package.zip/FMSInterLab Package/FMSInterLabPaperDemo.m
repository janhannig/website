% script FMSInterLabdemo.m
% data examples in paper ''

%% Scenario 0 
load('PaperDemo/S0D2K0.mat');
datastruct = struct('vxbar', Xbar, ...
                    'vse', SE, ...
                    'vdna', dna, ...
                    'vdnt', dnt, ...
                    'nfiducial', 10^5);
outstruct = FMSInterLab(datastruct);

musample = outstruct.musample;
muweight = outstruct.muweight;
sweight = sum(muweight);
k = 7; nfiducial = 100000;

figure(1)
xi=linspace(42,50,500);
[cf,~,u] = ksdensity(musample,xi,'weights',muweight/sweight,'bandwidth',.01);
plot(xi,cf,'k')
hold on
plot([min(xi),max(xi)],[0,0],'k--')
point = 0;
for i=1:k
    [f]=ksdensity(musample(((i-1)*nfiducial+1):(i*nfiducial)),xi);%,'bandwidth',.03);
    point = point + max(f)*1.1; 
    plot(xi,f-point,'b')
    plot([min(xi),max(xi)],-point*ones(1,2),'b--')
end
set(gca, 'YLim', [-point max(cf)])
title('Kernel Density Estimator', 'FontSize', 15);
set(gca,'YTick',[]) 

figure(2)
skip = 1;
[smusample,imusample]=sort(musample);
csweight=cumsum(muweight(imusample))/sweight;
smusample=[smusample,Inf];
csweight=[csweight,1];
cswxi=zeros(1,size(xi,2));
for j=1:size(xi,2)
    cswxi(j)=csweight(find(smusample>=xi(j),1,'first'));
end

plot(xi,abs(cswxi-.5)*2,'k')
hold on
plot([min(xi),max(xi)],.95*ones(1,2),'k--')
for i=1:k
    part=((i-1)*nfiducial+1):(i*nfiducial);
    [smupart,~]=sort(musample(part));
     cswxipart=zeros(1,size(xi,2));
    for j=1:size(xi,2)
       cswxipart(j)=sum(smupart<=xi(j))/nfiducial;
    end
    plot(xi,abs(cswxipart-.5)*2-i*skip,'b')
    plot([min(xi),max(xi)],.95*ones(1,2)-i*skip,'b--')
end
set(gca, 'YLim', [-k 1])
title(['Median =' num2str(smusample(find(csweight>.5,1,'first')), 5) ';'  ...
    ' 95% Confidence Interval: (' num2str(smusample(find(csweight>.025,1,'first')), 5') ',' num2str(smusample(find(csweight<.975,1,'last')), 5) ')'], ...
    'FontSize', 15)
set(gca,'YTick',[]) 

%% Scenario 1 
load('PaperDemo/S1D2K0.mat');
datastruct = struct('vxbar', Xbar, ...
                    'vse', SE, ...
                    'vdna', dna, ...
                    'vdnt', dnt, ...
                    'nfiducial', 10^5);
outstruct = FMSInterLab(datastruct);

musample = outstruct.musample;
muweight = outstruct.muweight;
sweight = sum(muweight);
k = 7; nfiducial = 100000;

figure(1)
xi=linspace(42,50,500);
[cf,~,u] = ksdensity(musample,xi,'weights',muweight/sweight,'bandwidth',.01);
plot(xi,cf,'k')
hold on
plot([min(xi),max(xi)],[0,0],'k--')
point = 0;
for i=1:k
    [f]=ksdensity(musample(((i-1)*nfiducial+1):(i*nfiducial)),xi);%,'bandwidth',.03);
    point = point + max(f)*1.1; 
    plot(xi,f-point,'b')
    plot([min(xi),max(xi)],-point*ones(1,2),'b--')
end
set(gca, 'YLim', [-point max(cf)])
title('Kernel Density Estimator', 'FontSize', 15);
set(gca,'YTick',[]) 

figure(2)
skip = 1;
[smusample,imusample]=sort(musample);
csweight=cumsum(muweight(imusample))/sweight;
smusample=[smusample,Inf];
csweight=[csweight,1];
cswxi=zeros(1,size(xi,2));
for j=1:size(xi,2)
    cswxi(j)=csweight(find(smusample>=xi(j),1,'first'));
end

plot(xi,abs(cswxi-.5)*2,'k')
hold on
plot([min(xi),max(xi)],.95*ones(1,2),'k--')
for i=1:k
    part=((i-1)*nfiducial+1):(i*nfiducial);
    [smupart,~]=sort(musample(part));
     cswxipart=zeros(1,size(xi,2));
    for j=1:size(xi,2)
       cswxipart(j)=sum(smupart<=xi(j))/nfiducial;
    end
    plot(xi,abs(cswxipart-.5)*2-i*skip,'b')
    plot([min(xi),max(xi)],.95*ones(1,2)-i*skip,'b--')
end
set(gca, 'YLim', [-k 1])
title(['Median =' num2str(smusample(find(csweight>.5,1,'first')), 5) ';'  ...
    ' 95% Confidence Interval: (' num2str(smusample(find(csweight>.025,1,'first')), 5') ',' num2str(smusample(find(csweight<.975,1,'last')), 5) ')'], ...
    'FontSize', 15)
set(gca,'YTick',[]) 


%% Scenario 2 
load('PaperDemo/S2D2K045.mat');
% load('PaperDemo/S2D2K048.mat'): second data example under scenario 2
datastruct = struct('vxbar', Xbar, ...
                    'vse', SE, ...
                    'vdna', dna, ...
                    'vdnt', dnt, ...
                    'nfiducial', 10^5);
outstruct = FMSInterLab(datastruct);

musample = outstruct.musample;
muweight = outstruct.muweight;
sweight = sum(muweight);
k = 7; nfiducial = 100000;

figure(1)
xi=linspace(42,50,500);
[cf,~,u] = ksdensity(musample,xi,'weights',muweight/sweight,'bandwidth',.01);
plot(xi,cf,'k')
hold on
plot([min(xi),max(xi)],[0,0],'k--')
point = 0;
for i=1:k
    [f]=ksdensity(musample(((i-1)*nfiducial+1):(i*nfiducial)),xi);%,'bandwidth',.03);
    point = point + max(f)*1.1; 
    plot(xi,f-point,'b')
    plot([min(xi),max(xi)],-point*ones(1,2),'b--')
end
set(gca, 'YLim', [-point max(cf)])
title('Kernel Density Estimator', 'FontSize', 15);
set(gca,'YTick',[]) 

figure(2)
skip = 1;
[smusample,imusample]=sort(musample);
csweight=cumsum(muweight(imusample))/sweight;
smusample=[smusample,Inf];
csweight=[csweight,1];
cswxi=zeros(1,size(xi,2));
for j=1:size(xi,2)
    cswxi(j)=csweight(find(smusample>=xi(j),1,'first'));
end

plot(xi,abs(cswxi-.5)*2,'k')
hold on
plot([min(xi),max(xi)],.95*ones(1,2),'k--')
for i=1:k
    part=((i-1)*nfiducial+1):(i*nfiducial);
    [smupart,~]=sort(musample(part));
     cswxipart=zeros(1,size(xi,2));
    for j=1:size(xi,2)
       cswxipart(j)=sum(smupart<=xi(j))/nfiducial;
    end
    plot(xi,abs(cswxipart-.5)*2-i*skip,'b')
    plot([min(xi),max(xi)],.95*ones(1,2)-i*skip,'b--')
end
set(gca, 'YLim', [-k 1])
title(['Median =' num2str(smusample(find(csweight>.5,1,'first')), 5) ';'  ...
    ' 95% Confidence Interval: (' num2str(smusample(find(csweight>.025,1,'first')), 5') ',' num2str(smusample(find(csweight<.975,1,'last')), 5) ')'], ...
    'FontSize', 15)
set(gca,'YTick',[]) 

%% Real data example - Steel Gauge Blocks
k=11;
Xbar =  [-1 1.5 4 2 9 -3 32 12 -2.2 -24.2 12]';
SE = [8 14 10 14 9.6 7.2 8 9 10.3 11 5.5]';
dna=6*ones(k,1);
dnt =60*ones(k,1);

datastruct = struct('vxbar', Xbar, ...
                    'vse', SE, ...
                    'vdna', dna, ...
                    'vdnt', dnt, ...
                    'nfiducial', 10^5);
outstruct = FMSInterLab(datastruct);

musample = outstruct.musample;
muweight = outstruct.muweight;
sweight = sum(muweight);
nfiducial = 100000;

figure(1)
xi=linspace(-50,50,500);
[cf,~,u] = ksdensity(musample,xi,'weights',muweight/sweight,'bandwidth',.01);
plot(xi,cf,'k')
hold on
plot([min(xi),max(xi)],[0,0],'k--')
point = 0;
for i=1:k
    [f]=ksdensity(musample(((i-1)*nfiducial+1):(i*nfiducial)),xi);%,'bandwidth',.03);
    point = point + max(f)*1.1; 
    plot(xi,f-point,'b')
    plot([min(xi),max(xi)],-point*ones(1,2),'b--')
end
set(gca, 'YLim', [-point max(cf)])
title('Kernel Density Estimator', 'FontSize', 15);
set(gca,'YTick',[]) 

figure(2)
skip = 1;
[smusample,imusample]=sort(musample);
csweight=cumsum(muweight(imusample))/sweight;
smusample=[smusample,Inf];
csweight=[csweight,1];
cswxi=zeros(1,size(xi,2));
for j=1:size(xi,2)
    cswxi(j)=csweight(find(smusample>=xi(j),1,'first'));
end

plot(xi,abs(cswxi-.5)*2,'k')
hold on
plot([min(xi),max(xi)],.95*ones(1,2),'k--')
for i=1:k
    part=((i-1)*nfiducial+1):(i*nfiducial);
    [smupart,~]=sort(musample(part));
     cswxipart=zeros(1,size(xi,2));
    for j=1:size(xi,2)
       cswxipart(j)=sum(smupart<=xi(j))/nfiducial;
    end
    plot(xi,abs(cswxipart-.5)*2-i*skip,'b')
    plot([min(xi),max(xi)],.95*ones(1,2)-i*skip,'b--')
end
set(gca, 'YLim', [-k 1])
title(['Median =' num2str(smusample(find(csweight>.5,1,'first')), 5) ';'  ...
    ' 95% Confidence Interval: (' num2str(smusample(find(csweight>.025,1,'first')), 5') ',' num2str(smusample(find(csweight<.975,1,'last')), 5) ')'], ...
    'FontSize', 15)
set(gca,'YTick',[]) 

%% Real data example - Big G
k=11;
Xbar = [6.67248 ;
            6.6729 ;
            6.67398 ;
            6.674255 ;
            6.67559 ;
            6.67422 ;
            6.67387 ;
            6.67228 ;
            6.67425 ;
            6.67349 ;
            6.67234] ;
SE =  [  0.00043 ;
                0.0005 ;
                0.0007 ;
                0.000092 ;
                0.00027 ;
                0.00098 ;
                0.00027 ;
                0.00087 ;
                0.00012 ;
                0.00018 ;
                0.00014] ;
dna=6*ones(k,1);
dnt = 60*ones(k,1);

datastruct = struct('vxbar', Xbar, ...
                    'vse', SE, ...
                    'vdna', dna, ...
                    'vdnt', dnt, ...
                    'nfiducial', 10^5);
outstruct = FMSInterLab(datastruct);

musample = outstruct.musample;
muweight = outstruct.muweight;
sweight = sum(muweight);
nfiducial = 100000;

figure(1)
xi=linspace(6.67,6.6765,500);
[cf,~,u] = ksdensity(musample,xi,'weights',muweight/sweight,'bandwidth',.01);
plot(xi,cf,'k')
hold on
plot([min(xi),max(xi)],[0,0],'k--')
point = 0;
for i=1:k
    [f]=ksdensity(musample(((i-1)*nfiducial+1):(i*nfiducial)),xi);%,'bandwidth',.03);
    point = point + max(f)*1.1; 
    plot(xi,f-point,'b')
    plot([min(xi),max(xi)],-point*ones(1,2),'b--')
end
set(gca, 'YLim', [-point max(cf)])
title('Kernel Density Estimator', 'FontSize', 15);
set(gca,'YTick',[]) 

figure(2)
skip = 1;
[smusample,imusample]=sort(musample);
csweight=cumsum(muweight(imusample))/sweight;
smusample=[smusample,Inf];
csweight=[csweight,1];
cswxi=zeros(1,size(xi,2));
for j=1:size(xi,2)
    cswxi(j)=csweight(find(smusample>=xi(j),1,'first'));
end

plot(xi,abs(cswxi-.5)*2,'k')
hold on
plot([min(xi),max(xi)],.95*ones(1,2),'k--')
for i=1:k
    part=((i-1)*nfiducial+1):(i*nfiducial);
    [smupart,~]=sort(musample(part));
     cswxipart=zeros(1,size(xi,2));
    for j=1:size(xi,2)
       cswxipart(j)=sum(smupart<=xi(j))/nfiducial;
    end
    plot(xi,abs(cswxipart-.5)*2-i*skip,'b')
    plot([min(xi),max(xi)],.95*ones(1,2)-i*skip,'b--')
end
set(gca, 'YLim', [-k 1])
title(['Median =' num2str(smusample(find(csweight>.5,1,'first')), 5) ';'  ...
    ' 95% Confidence Interval: (' num2str(smusample(find(csweight>.025,1,'first')), 5') ',' num2str(smusample(find(csweight<.975,1,'last')), 5) ')'], ...
    'FontSize', 15)
set(gca,'YTick',[]) 

%% paper-simulation demo 