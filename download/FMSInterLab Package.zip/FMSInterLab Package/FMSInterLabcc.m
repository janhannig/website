function FMSInterLabcc(musample, muweight, k)
% function to plot confidence curves of fiducal samples for each lab

% output: graphic only
nfiducial = length(musample)/k;
sweight = sum(muweight);

figure
%note: xi can be potentially tuned for better looking pictures. e.g.
%min(musample),max(musample) if no heavy tail
xi = linspace(prctile(musample, 0.1), prctile(musample, 99.9),300);%min(musample),max(musample)
[smusample, imusample] = sort(musample);
csweight = cumsum(muweight(imusample))/sweight;

skip=1;
smusample = [smusample,Inf];
csweight = [csweight,1];

cswxi = zeros(1,length(xi));
for j = 1:length(xi)
    cswxi(j) = csweight(find(smusample >= xi(j),1,'first'));
end

plot(xi, abs(cswxi-.5)*2, 'k')
hold on
plot([min(xi),max(xi)], .95*ones(1,2), 'k--')

for i=1:k
    part = ((i-1)*nfiducial+1):(i*nfiducial);
    [smupart,~] = sort(musample(part));
    cswxipart = zeros(1,length(xi));
    for j = 1:length(xi)
       cswxipart(j) = sum(smupart<=xi(j))/nfiducial;
    end

    plot(xi, abs(cswxipart-.5)*2-i*skip, 'b')
    plot([min(xi),max(xi)], .95*ones(1,2)-i*skip, 'b--')
end
title('Confidence Curves')
print -dpsc 'FMSInterLabCCplot';