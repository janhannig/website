function FMSInterLabkde(musample, muweight, k)
% function to plot kernel density estimates of fiducal samples for each lab

% output: graphic only

nfiducial = length(musample)/k;
sweight = sum(muweight);

figure;
%note: xi can be potentially tuned for better looking pictures. e.g.
%min(musample),max(musample) if no heavy tail
xi = linspace(prctile(musample, 0.1), prctile(musample, 99.9),300);
%note: skip can be tuned as well. e.g. if a narrow kde is given, you may
%consider increase skip to avoid overlapping
skip = 2;
[cf,~,u] = ksdensity(musample, xi,'weights', muweight/sweight,'bandwidth',.001);
plot(xi,cf,'k')
hold on
plot([min(xi),max(xi)],[0,0],'k--')
for i=1:k
    [f] = ksdensity(musample(((i-1)*nfiducial+1):(i*nfiducial)),xi);
    plot(xi,f-skip*i,'b')
    plot([min(xi),max(xi)], -skip*i*ones(1,2), 'b--')
end
title('Kernel Density Estimate');
print -dpsc 'FMSInterLabKDEplot';