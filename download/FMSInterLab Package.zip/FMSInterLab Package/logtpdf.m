function lt=logtpdf(x,n)
% function to compute log-likelihood of t-distribution
% 
% Inputs:
% x: a vector of observation
% n: degrees of freedom
% Output
% lt: log-likelihood of t-distribution

%    Copyright (c)  Jan Hannig, Hari Iyer & Qing Feng 2016

lt=gammaln((n+1)/2)-gammaln(n/2)-log(n)/2-log(pi)/2-((n+1)/2)*log(1+x.^2/n);
